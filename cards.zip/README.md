# Black Jack

[![](logo.jpg)](https://github.com/Z-100/CardGameAPI/blob/main/logo.jpg)

## API
Deck of Cards API: _http://deckofcardsapi.com/_

## The developers
_Z-100, N4choWasTaken, Jerome-Luethi, Stricker97, MagischerWolf05_

## How to use it
PrEsS tHe BuTtOnS

## How it works

### How to gain points
Both, the player and the computer will get two random cards.
If the **sum of the players cards is larger than the computers**
the player will gain **1 point**. 
If the **sum of the players cards is exactly 21** the player will
gain **2 points**.
If the computer and the players cards **both are exactly 21, the player
won't gain nor lose points**.

### How to lose points
If the **sum of the players cards is smaller than the computers**
or **larger than "21"** the player will **lose his/her points**
