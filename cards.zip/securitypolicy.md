# Security Policy

## Supported versions

No version is currently being supported 
with frequent security updates.

| Version | Supported          |
| ------- | ------------------ |
| 0.0.1   | :x:                |

## We don't want feedback. But feel free
to send us bug reports. (Just be aware of
the fact that no one of our developer team
will ever fix 'em)

To report just send an email to cardgameapi@gmail.com

There will be no updates
